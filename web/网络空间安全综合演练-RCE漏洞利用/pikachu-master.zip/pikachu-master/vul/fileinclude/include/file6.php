<?php
$html.=<<<A
<p class=nabname>
here is a secret box!<br />
admin/admin<br />
kobe/123456<br />
</p>
A;
?>