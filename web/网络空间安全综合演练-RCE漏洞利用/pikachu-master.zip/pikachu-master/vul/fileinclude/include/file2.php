<?php
$html.=<<<A
<img class=player src="include/ai.png" />
<p class=nabname>
Allen Iverson (Allen Iverson), was born on June 7, 1975 in the United States in Hampton, Virginia, a former American professional basketball player, the secretary defender (double can guard), 11 times in NBA all-star squad, a former U.S. dream team captain.Over the years, do you remember his pace of the cross?
</p>
A;
?>