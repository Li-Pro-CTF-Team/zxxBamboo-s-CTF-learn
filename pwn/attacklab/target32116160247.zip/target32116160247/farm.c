/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_232(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_219(unsigned x)
{
    return x + 2496104776U;
}

unsigned getval_127()
{
    return 3150149815U;
}

void setval_269(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_456()
{
    return 3267856712U;
}

unsigned getval_207()
{
    return 2438496823U;
}

void setval_307(unsigned *p)
{
    *p = 2421728705U;
}

unsigned getval_249()
{
    return 3347662894U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_178(unsigned *p)
{
    *p = 3223374473U;
}

unsigned getval_254()
{
    return 3375939977U;
}

void setval_189(unsigned *p)
{
    *p = 3767097377U;
}

void setval_161(unsigned *p)
{
    *p = 3247046090U;
}

unsigned getval_397()
{
    return 3286272328U;
}

unsigned addval_109(unsigned x)
{
    return x + 3674786445U;
}

unsigned getval_365()
{
    return 3683959177U;
}

unsigned getval_423()
{
    return 3767093452U;
}

void setval_382(unsigned *p)
{
    *p = 3252062708U;
}

void setval_115(unsigned *p)
{
    *p = 3674789513U;
}

unsigned addval_250(unsigned x)
{
    return x + 3373845129U;
}

unsigned addval_164(unsigned x)
{
    return x + 3284238748U;
}

unsigned addval_494(unsigned x)
{
    return x + 3286272330U;
}

unsigned getval_316()
{
    return 3599465145U;
}

unsigned addval_210(unsigned x)
{
    return x + 3678978441U;
}

unsigned addval_354(unsigned x)
{
    return x + 3375945353U;
}

void setval_102(unsigned *p)
{
    *p = 3525891721U;
}

void setval_288(unsigned *p)
{
    *p = 3676362379U;
}

unsigned getval_370()
{
    return 2462157281U;
}

unsigned getval_211()
{
    return 3225998985U;
}

unsigned addval_124(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_156(unsigned x)
{
    return x + 3229139337U;
}

unsigned addval_398(unsigned x)
{
    return x + 3680553609U;
}

unsigned addval_107(unsigned x)
{
    return x + 3373845129U;
}

unsigned addval_131(unsigned x)
{
    return x + 3238629486U;
}

unsigned getval_478()
{
    return 3523791369U;
}

unsigned addval_419(unsigned x)
{
    return x + 3286270280U;
}

unsigned getval_267()
{
    return 3385117321U;
}

unsigned addval_130(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_141(unsigned x)
{
    return x + 3286272344U;
}

unsigned getval_283()
{
    return 2425408137U;
}

unsigned getval_339()
{
    return 3221804697U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
